<?php 
require 'includes/db.php';
require 'config/config.php';

$erro = "";

// Verificar se a tarefa existe e se o id foi passado
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM tarefas WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $tarefa = $result->fetch_assoc();
    } else {
        echo "Tarefa não encontrada.";
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nome = htmlspecialchars($_POST['nome']);
        $custo = $_POST['custo'];
        $data_limite = $_POST['data_limite'];
        $ordem_apresentacao = $_POST['ordem_apresentacao'];

        if (empty($nome) || empty($custo) || empty($data_limite) || empty($ordem_apresentacao)) {
            $erro = "Todos os campos devem ser preenchidos!";
        } else {
            $updateQuery = "UPDATE tarefas SET nome = ?, custo = ?, data_limite = ?, ordem_apresentacao = ? WHERE id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("sdssi", $nome, $custo, $data_limite, $ordem_apresentacao, $id);

            if ($stmt->execute()) {
                header('Location: index.php');
                exit();
            } else {
                $erro = "Erro: " . $stmt->error;
            }
        }
    }
} else {
    echo "ID inválido ou não fornecido.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Tarefa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h1>Editar Tarefa</h1>
    <?php if (!empty($erro)): ?>
        <div class="erro"><?= $erro ?></div>
    <?php endif; ?>
    <form method="POST">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" value="<?= htmlspecialchars($tarefa['nome']) ?>" required>

        <label for="custo">Custo:</label>
        <input type="number" name="custo" id="custo" value="<?= htmlspecialchars($tarefa['custo']) ?>" step="0.01" required>

        <label for="data_limite">Data Limite:</label>
        <input type="date" name="data_limite" id="data_limite" value="<?= htmlspecialchars($tarefa['data_limite']) ?>" required>

        <label for="ordem_apresentacao">Ordem de Apresentação:</label>
        <input type="number" name="ordem_apresentacao" id="ordem_apresentacao" value="<?= htmlspecialchars($tarefa['ordem_apresentacao']) ?>" required>

        <button type="submit">Atualizar</button>
    </form>
</body>
</html>
