<?php
define('BASE_URL', 'https://node167510-lista-de-tarefas.jcloud-ver-jpe.ik-server.com');
?>
