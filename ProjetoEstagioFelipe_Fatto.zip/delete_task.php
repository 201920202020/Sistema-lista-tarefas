<?php
// Incluir conexões de banco de dados
require 'includes/db.php';
require 'config/config.php';


if (isset($_GET['id'])) {
    $taskId = $_GET['id'];

    // Deletar tarefa
    $query = "DELETE FROM tarefas WHERE id = $taskId";
    $conn->query($query);

    header('Location: index.php');
}
?>
