document.addEventListener('DOMContentLoaded', function () {
    console.log("Script carregado com sucesso!");
});
