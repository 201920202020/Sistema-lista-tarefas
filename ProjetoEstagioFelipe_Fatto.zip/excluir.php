<?php
// Incluir conexões de banco de dados
require 'includes/db.php';
require 'config/config.php';

// Verificar se o id foi passado
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Deletar a tarefa do banco de dados
    $query = "DELETE FROM tarefas WHERE id = $id";
    
    if ($conn->query($query) === TRUE) {
        // Redirecionar para a página principal após exclusão
        header('Location: index.php');
        exit();
    } else {
        echo "Erro: " . $conn->error;
    }
} else {
    echo "ID não fornecido.";
    exit();
}
?>
