<?php
// Incluir conexões de banco de dados
require 'includes/db.php';
require 'config/config.php';

// Adicionar uma nova tarefa (caso o formulário seja enviado)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nome'])) {
    $nome = $_POST['nome'];
    $custo = $_POST['custo'];
    $dataLimite = $_POST['data_limite'];

    // Verifica se já existe uma tarefa com o mesmo nome
    $query = "SELECT * FROM tarefas WHERE nome = '$nome'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $erro = "Erro: Já existe uma tarefa com esse nome!";
    } else {
        // Consultar a maior ordem atual
        $query = "SELECT MAX(ordem_apresentacao) AS max_order FROM tarefas";
        $result = $conn->query($query);
        $maxOrder = $result->fetch_assoc()['max_order'] + 1;

        // Inserir nova tarefa
        $query = "INSERT INTO tarefas (nome, custo, data_limite, ordem_apresentacao) 
                  VALUES ('$nome', '$custo', '$dataLimite', '$maxOrder')";
        if ($conn->query($query)) {
            $sucesso = "Tarefa adicionada com sucesso!";
        } else {
            $erro = "Erro ao adicionar tarefa.";
        }
    }
}

// Buscar tarefas ordenadas pela ordem de apresentação
$query = "SELECT * FROM tarefas ORDER BY ordem_apresentacao";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Tarefas</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function moveUp(taskId) {
            fetch('move_task.php', {
                method: 'POST',
                body: JSON.stringify({ taskId: taskId, direction: 'up' })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function moveDown(taskId) {
            fetch('move_task.php', {
                method: 'POST',
                body: JSON.stringify({ taskId: taskId, direction: 'down' })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function confirmDelete(taskId) {
            if (confirm('Você tem certeza que deseja excluir esta tarefa?')) {
                window.location.href = `delete_task.php?id=${taskId}`;
            }
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Lista de Tarefas</h1>
        <?php if (!empty($erro)): ?>
            <div class="alert alert-danger"><?= $erro ?></div>
        <?php endif; ?>
        <?php if (!empty($sucesso)): ?>
            <div class="alert alert-success"><?= $sucesso ?></div>
        <?php endif; ?>

        <form method="POST" class="mb-4">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome da Tarefa:</label>
                <input type="text" name="nome" id="nome" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="custo" class="form-label">Custo (R$):</label>
                <input type="number" name="custo" id="custo" class="form-control" step="0.01" required>
            </div>
            <div class="mb-3">
                <label for="data_limite" class="form-label">Data Limite:</label>
                <input type="date" name="data_limite" id="data_limite" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Adicionar Tarefa</button>
        </form>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Nome da Tarefa</th>
                    <th>Custo</th>
                    <th>Data Limite</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($task = $result->fetch_assoc()) { 
                    $highlightClass = $task['custo'] >= 1000 ? 'table-warning' : '';
                ?>
                    <tr id="task-<?= $task['id'] ?>" class="<?= $highlightClass ?>">
                        <td><?= htmlspecialchars($task['nome']) ?></td>
                        <td>R$ <?= number_format($task['custo'], 2, ',', '.') ?></td>
                        <td><?= htmlspecialchars($task['data_limite']) ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <button class="btn btn-secondary btn-sm" onclick="moveUp(<?= $task['id'] ?>)">Subir</button>
                                <button class="btn btn-secondary btn-sm" onclick="moveDown(<?= $task['id'] ?>)">Descer</button>
                                <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?= $task['id'] ?>)">Excluir</button>
                                <a href="editar.php?id=<?= $task['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
