<?php
$host = 'node167510-lista-de-tarefas.jcloud-ver-jpe.ik-server.com';
$user = 'root';
$password = 'XDCvcb33431';
$dbname = 'sistarefas';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Erro ao conectar ao banco de dados: " . $conn->connect_error);
}
?>
