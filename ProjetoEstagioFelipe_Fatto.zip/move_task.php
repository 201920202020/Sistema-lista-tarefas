<?php
require 'includes/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$taskId = $data['taskId'];
$direction = $data['direction'];

// Consultar a posição atual da tarefa
$query = "SELECT ordem_apresentacao FROM tarefas WHERE id = $taskId";
$result = $conn->query($query);
$currentOrder = $result->fetch_assoc()['ordem_apresentacao'];

// Determinar a nova ordem
if ($direction == 'up') {
    $newOrder = $currentOrder - 1;
} else {
    $newOrder = $currentOrder + 1;
}

// Verificar a nova ordem e atualizar no banco de dados
$query = "UPDATE tarefas SET ordem_apresentacao = $newOrder WHERE id = $taskId";
$conn->query($query);

// Reorganizar as tarefas se necessário
$query = "UPDATE tarefas SET ordem_apresentacao = $currentOrder WHERE id != $taskId AND ordem_apresentacao = $newOrder";
$conn->query($query);

echo json_encode(['success' => true]);
?>
