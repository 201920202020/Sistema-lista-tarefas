<?php
// Incluir conexões de banco de dados
require 'includes/db.php';
require 'config/config.php';

// Verificar se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Coletar dados do formulário
    $nome = $_POST['nome'];
    $custo = $_POST['custo'];
    $data_limite = $_POST['data_limite'];
    $ordem_apresentacao = $_POST['ordem_apresentacao'];

    // Inserir dados no banco de dados
    $query = "INSERT INTO tarefas (nome, custo, data_limite, ordem_apresentacao) 
              VALUES ('$nome', '$custo', '$data_limite', '$ordem_apresentacao')";
    
    if ($conn->query($query) === TRUE) {
        // Redirecionar para a página principal após inserção bem-sucedida
        header('Location: index.php');
        exit();
    } else {
        echo "Erro: " . $query . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Tarefa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h1>Cadastrar Nova Tarefa</h1>
    <form method="POST">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" required>

        <label for="custo">Custo:</label>
        <input type="number" name="custo" id="custo" step="0.01" required>

        <label for="data_limite">Data Limite:</label>
        <input type="date" name="data_limite" id="data_limite" required>

        <label for="ordem_apresentacao">Ordem de Apresentação:</label>
        <input type="number" name="ordem_apresentacao" id="ordem_apresentacao" required>

        <button type="submit">Cadastrar</button>
    </form>
</body>
</html>
