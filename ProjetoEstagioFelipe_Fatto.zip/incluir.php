<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome_tarefa = $_POST['nome_tarefa'];
    $custo = $_POST['custo'];
    $data_limite = $_POST['data_limite'];

    $sql = "INSERT INTO tarefas (nome_tarefa, custo, data_limite, ordem_apresentacao) VALUES ('$nome_tarefa', '$custo', '$data_limite', (SELECT MAX(ordem_apresentacao) + 1 FROM tarefas))";
    
    if ($conn->query($sql) === TRUE) {
        echo "Nova tarefa incluída com sucesso!";
    } else {
        echo "Erro: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incluir Tarefa</title>
</head>
<body>
    <h1>Incluir Nova Tarefa</h1>
    <form method="POST">
        <label for="nome_tarefa">Nome da Tarefa:</label>
        <input type="text" id="nome_tarefa" name="nome_tarefa" required><br>
        
        <label for="custo">Custo (R$):</label>
        <input type="number" id="custo" name="custo" required><br>
        
        <label for="data_limite">Data Limite:</label>
        <input type="date" id="data_limite" name="data_limite" required><br>
        
        <input type="submit" value="Incluir Tarefa">
    </form>
</body>
</html>
